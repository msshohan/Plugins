<?php

if( !class_exists('msrv_view_list')){
	class msrv_view_list{

		// define variables
		private $msrv_label = "Recently Viewed Products";
		private $options = [];

		public function __construct(){
				$this->options = get_option( 'rvpplugin_settings' );
		}


		public function msrv_show($no_of_prods,$array_viewed_ids,$wrap_slider){
			$count = 0;
			//print_r( $no_of_prods);
			if($no_of_prods <= 0 ){ //show all products
					if( is_product()){
							array_shift($array_viewed_ids);
					}
					$array_ids_to_show = $array_viewed_ids;
			} else {
					if(is_product()){
							$array_ids_to_show = array_slice($array_viewed_ids,1,(int)$no_of_prods);
					} else {
							$array_ids_to_show = array_slice($array_viewed_ids,0,(int)$no_of_prods);
					}

					// slice to array from 1 so that current item doesnot shows in rvp in product page
					// slice from 0 to slice it till no of products
			}


			$max_prods = count($array_ids_to_show);
			//print_r( $array_ids_to_show);
			$the_query = new WP_Query( array(
				'post_type'  =>  'product',
				'post_status'  =>  'publish',
				'posts_per_page' => '-1',
				'post__in'  =>  $array_ids_to_show,
				'orderby' => 'post__in'
			));
			$total = $the_query->found_posts;
			$wrap_slider=preg_replace('/^(\'(.*)\'|"(.*)")$/', '$2$3', $wrap_slider);

			if ( $the_query->have_posts() ) {
					_e( '<section class="recent_products">' ) ;
					_e('<h2>'. $this->msrv_label.'</h2>');
					if ($wrap_slider == "true" || $wrap_slider == '1' ){
							_e( '<ul class="products rvpscarousel">');

					} elseif($wrap_slider == "false" || $wrap_slider == '0' ){
						/* columns-<?php echo esc_attr( wc_get_loop_prop( 'columns' ) ); ?>*/
							_e( '<ul class="products columns-'. wc_get_loop_prop( 'columns' ) .'">');
					} else {
							_e( '<ul class="products">');
					}
					while ( $the_query->have_posts()  && $count < $max_prods  ) {
								$the_query->the_post();
								wc_get_template_part( 'content', 'product' );
								$count++;
						}


					_e('</ul>');
					_e('</section>') ;
				/* Restore  Post Data */
				wp_reset_postdata();
			}else{
				_e( '<section class="recent_products">' ) ;
				_e('<h2>'. $this->msrv_label.'</h2>');
				_e('No Products Viewed so far !');
				_e('</section>') ;
				return ;
			}
		}

		public function msrv_view_guest($no_of_prods,$wrap_slider){
			if( !isset($_COOKIE['rvpguest'] )) return ;
			$array_values = unserialize($_COOKIE['rvpguest']);
			$this->msrv_show($no_of_prods,$array_values,$wrap_slider);

		}

		public function msrv_view_logged_in($no_of_prods,$wrap_slider){
				$currentUser = get_current_user_id();
		    $msrv_user = 'msrv_'.$currentUser;
		    $msrv_post = get_page_by_title($msrv_user,'' , 'rvp');

		    if( $msrv_post ) {
		        $msrv_id = $msrv_post->ID;
		        $viewed_ids = get_post_meta($msrv_id,'viewedids',true);
		        $array_viewed_ids = explode(',',$viewed_ids);
			//			print_r($array_viewed_ids);
		       	$this->msrv_show($no_of_prods,$array_viewed_ids,$wrap_slider);
						//$this->msrv_sc_show($no_of_prods,$array_viewed_ids,$wrap_slider);

		    } // if msrv_post
		}

		public function msrv_view_shortcode(){
			ob_start();
			$this->msrv_view_single();
			return ob_get_clean();
		}

		public function msrv_view_single_short($no_of_prods,$wrap_slider){
			ob_start();
			if( isset( $this->options[ 'msrv_label' ] ) && ($this->options[ 'msrv_label' ] != '')  ) {
				$this->msrv_label = __( $this->options['msrv_label'] );
			}
			global $wp_scripts;
			$wp_scripts->add_data('rvpplugin-frontend', 'rvpplugin_data', '');
			$rvparr = array(
	      'slides_to_show' => $no_of_prods
	    );
			wp_localize_script('rvpplugin-frontend', 'rvpplugin_data',$rvparr);

			if($wrap_slider == 'true' || $wrap_slider == '1' ){
				$no_of_prods = '-1';
			}
			if(is_user_logged_in()){
				$this->msrv_view_logged_in($no_of_prods,$wrap_slider);
			} else {
				$this->msrv_view_guest($no_of_prods,$wrap_slider);
			}
			return ob_get_clean();
		}

		public function msrv_view_single(){
			$no_to_pass;
			$no_of_prods = 3;
			$no_of_prods_slider;
			$wrap_slider = false;
			if( isset( $this->options[ 'msrv_label' ] ) && ($this->options[ 'msrv_label' ] != '')  ) {
				$this->msrv_label = __( $this->options['msrv_label'] );
			}

			if( isset( $this->options[ 'no_of_prods' ] ) && ($this->options[ 'no_of_prods' ] != '') ) {
			    $no_of_prods = esc_html( $this->options['no_of_prods'] );
			} else {
				$no_of_prods = '3';
			}
			$checkbox = '';
			if( isset( $this->options[ 'checkbox' ] ) ) {
				$checkbox = esc_html( $this->options['checkbox'] );
			if( isset( $this->options[ 'no_of_prods_slider' ] ) && ($this->options[ 'no_of_prods_slider' ] != '') ) {
			    $no_of_prods_slider = esc_html( $this->options['no_of_prods_slider'] );
			  } else{
					$no_of_prods_slider = '-1';
				}
			}

			if($checkbox == '1' ){
				$no_to_pass = $no_of_prods_slider;
				$wrap_slider = true;
			} else {
				$no_to_pass = $no_of_prods;
				$wrap_slider = false;
			}


			if(is_user_logged_in()){
				$this->msrv_view_logged_in($no_to_pass,$wrap_slider);
			} else {
				$this->msrv_view_guest($no_to_pass,$wrap_slider);
			}

		} //end of function msrv_view_single

	} //class msrv_view_list
}
