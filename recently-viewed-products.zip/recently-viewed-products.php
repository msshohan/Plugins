<?php
/*
Plugin Name: Recently Viewed Products
Plugin URI: https://github.com/rajnisharora/rvp
Description: Plugin to view recently viewed products in Woocommerce e-store
Version: 1.0.0
Contributors: rajarora795
Author: Rajnish Arora
Author URI:
License: GPLv2 or later
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: rvpplugin
Domain Path:  /languages
*/

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
  die("Not allowed to access directly");
}

if ( !in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
  die("Please install WooCommerce & try again");
}
// Define plugin paths and URLs

//$options = get_option( 'rvpplugin_settings' );

define( 'RVPPLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'RVPPLUGIN_DIR', plugin_dir_path( __FILE__ ) );


// Create Settings Fields
include( plugin_dir_path( __FILE__ ) . 'includes/rvpplugin-settings-fields.php');

// Create Plugin Admin Menus and Setting Pages
include( plugin_dir_path( __FILE__ ) . 'includes/rvpplugin-styles.php');
include( plugin_dir_path( __FILE__ ) . 'includes/rvpplugin-scripts.php');

include( plugin_dir_path( __FILE__ ) . 'includes/rvpplugin-menus.php');


// create a new custom post type rvp for storing ids
include( plugin_dir_path( __FILE__ ) . 'includes/rvppost_types.php');
include( plugin_dir_path( __FILE__ ) . 'includes/rvpclass_create_metabox.php');
include( plugin_dir_path( __FILE__ ) . 'includes/rvpclass_create_list.php');
include( plugin_dir_path( __FILE__ ) . 'includes/rvpclass_view_list.php');
include( plugin_dir_path( __FILE__ ) . 'includes/msrv_actions.php');
include( plugin_dir_path( __FILE__ ) . 'shortcodes/msrv_shortcodes_view.php');


// Add a link to your settings page in your plugin
function rvpplugin_add_settings_link( $links ) {
    $settings_link = '<a href="admin.php?page=rvpplugin">' . __( 'Settings', 'rvpplugin'  ) . '</a>';
    array_push( $links, $settings_link );
  	return $links;
}
$filter_name = "plugin_action_links_" . plugin_basename( __FILE__ );
add_filter( $filter_name, 'rvpplugin_add_settings_link' );
