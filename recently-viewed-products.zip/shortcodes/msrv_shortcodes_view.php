<?php
/**
 * @package
 *
 */
 add_shortcode('msrv_show', function($atts){
		if ( !isset($msrv_view_object) ){
				$msrv_view_object = new msrv_view_list;
		}
    if(!$atts){
        return $msrv_view_object->msrv_view_shortcode();
    } else{
      $a = shortcode_atts( array(
        'no_products' => '3',
        'slider_use' => 'true',
      ), $atts );
      return $msrv_view_object->msrv_view_single_short($a['no_products'],$a['slider_use']);
    }

});
