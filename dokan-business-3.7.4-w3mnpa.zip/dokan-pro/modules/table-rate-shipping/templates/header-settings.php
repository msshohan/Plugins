<div class="dokan-text-left">
    <p>&larr; <a href="<?php echo esc_url( dokan_get_navigation_url() . 'settings/shipping/#/zone/' . $zone_id ); ?>"><?php esc_html_e( 'Back to Zone', 'dokan' ); ?></a></p>
</div>
