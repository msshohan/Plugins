<?php // phpcs:ignore Internal.NoCodeFound ?>
<fieldset id="dokan-stripe-express-form" class="dokan-stripe-express-form wc-payment-form">
    <div id="dokan-stripe-express-element"></div>
    <div id="dokan-stripe-express-errors" role="alert"></div>
    <div id="dokan-stripe-express-payment-message" class="hidden"></div>
    <input id="dokan-stripe-express-payment-method" type="hidden" name="dokan_stripe_express_payment_method" />
    <input id="dokan-stripe-express-payment-type" type="hidden" name="dokan_stripe_express_payment_type" />
</fieldset>
