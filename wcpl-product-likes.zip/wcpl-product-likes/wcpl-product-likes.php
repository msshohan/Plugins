<?php

/**
 * Plugin Name: Product Likes
 * Plugin URI: https://woocommerce.com/products/product-likes/
 * Description: Allow users to like products in your WooCommerce store and view previous likes in their account.
 * Version: 2.0.2
 * Author: 99w
 * Author URI: https://99w.co.uk
 * Developer: 99w
 * Developer URI: https://99w.co.uk
 * Text Domain: wcpl-product-likes
 * Domain Path: /languages
 *
 * Woo: 5742633:d07fa20192a58bfdc6f0df20b0a3c13d
 * WC requires at least: 4.0.0
 * WC tested up to: 6.3.1
 *
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( !class_exists( 'WCPL_Product_Likes' ) ) {

	define( 'WCPL_PRODUCT_LIKES_VERSION', '2.0.2' );

	class WCPL_Product_Likes {

		public function __construct() {

			require_once( __DIR__ . '/includes/class-wcpl-product-likes-activation.php' );
			require_once( __DIR__ . '/includes/class-wcpl-product-likes-translation.php' );
			require_once( __DIR__ . '/includes/class-wcpl-product-likes-upgrade.php' );
			
			new WCPL_Product_Likes_Activation();
			new WCPL_Product_Likes_Translation();
			new WCPL_Product_Likes_Upgrade();

			include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

			if ( is_plugin_active( 'woocommerce/woocommerce.php' ) ) {

				require_once( __DIR__ . '/includes/class-wcpl-product-likes-account.php' );
				require_once( __DIR__ . '/includes/class-wcpl-product-likes-dashboard.php' );
				require_once( __DIR__ . '/includes/class-wcpl-product-likes-debug.php' );
				require_once( __DIR__ . '/includes/class-wcpl-product-likes-display.php' );
				require_once( __DIR__ . '/includes/class-wcpl-product-likes-enqueues.php' );
				require_once( __DIR__ . '/includes/class-wcpl-product-likes-misc.php' );
				require_once( __DIR__ . '/includes/class-wcpl-product-likes-settings.php' );

				new WCPL_Product_Likes_Dashboard();
				new WCPL_Product_Likes_Debug();
				new WCPL_Product_Likes_Enqueues();
				new WCPL_Product_Likes_Misc();
				new WCPL_Product_Likes_Settings();

				if ( 'yes' == get_option( 'wcpl_product_likes_enable' ) ) {

					if ( 'yes' == get_option( 'wcpl_product_likes_account' ) ) {

						new WCPL_Product_Likes_Account();

					}

					new WCPL_Product_Likes_Display();

				}

			} else {

				add_action( 'admin_notices', function() {

					if ( current_user_can( 'edit_plugins' ) ) {
				
						?>
				
						<div class="notice notice-error">
							<p><strong><?php esc_html_e( 'Product Likes requires WooCommerce to be installed and activated.', 'wcpl-product-likes' ); ?></strong></p>
						</div>
				
						<?php
				
					}
				
				});

			}

		}

	}

	new WCPL_Product_Likes();

}
