=== Product Likes ===
Contributors: ninetyninew
Tags: product likes, product, likes, like, social
Requires at least: 5.0
Tested up to: 5.9.2
Requires PHP: 7.0
Stable tag: 2.0.2
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

For further information on this extension:

https://woocommerce.com/products/product-likes/
https://woocommerce.com/document/product-likes/