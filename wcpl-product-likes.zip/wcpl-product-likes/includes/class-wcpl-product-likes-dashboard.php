<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( !class_exists( 'WCPL_Product_Likes_Dashboard' ) ) {

	class WCPL_Product_Likes_Dashboard {

		public function __construct() {

			add_action( 'admin_menu', array( $this, 'menu_page' ) );
			add_action( 'wp_ajax_wcpl_product_likes_dashboard_modal_population', array( $this, 'modal_population' ) );

		}

		public function menu_page() {

			add_submenu_page(
				'edit.php?post_type=product',
				esc_html__( 'Product Likes', 'wcpl-product-likes' ),
				esc_html__( 'Likes', 'wcpl-product-likes' ),
				'manage_woocommerce',
				'wcpl-product-likes',
				array( $this, 'render' ),
				10
			);

		}

		public function render() {

			global $wpdb;

			if ( isset( $_GET['tab'] ) ) {

				$tab = sanitize_text_field( $_GET['tab'] );

				if ( empty( $tab ) ) {

					$tab = 'product-totals';

				}

			} else {

				$tab = 'product-totals';

			}

			?>

			<div class="wcpl-product-likes-dashboard wrap">
				<h1 class="wp-heading-inline"><?php esc_html_e( 'Product Likes', 'wcpl-product-likes' ); ?></h1>
				<a href="<?php echo esc_url( get_admin_url() . 'admin.php?page=wc-settings&tab=products&section=wcpl-product-likes' ); ?>" class="page-title-action"><?php esc_html_e( 'Settings', 'wcpl-product-likes' ); ?></a>
				<hr class="wp-header-end">
				<nav class="nav-tab-wrapper">
					<a href="<?php echo esc_url_raw( add_query_arg( 'tab', 'product-totals' ) ); ?>" class="nav-tab<?php echo ( 'product-totals' == $tab ? ' nav-tab-active' : '' ); ?>"><?php esc_html_e( 'Product Totals', 'wcpl-product-likes' ); ?></a>
					<a href="<?php echo esc_url_raw( add_query_arg( 'tab', 'customer-totals' ) ); ?>" class="nav-tab<?php echo ( 'customer-totals' == $tab ? ' nav-tab-active' : '' ); ?>"><?php esc_html_e( 'Customer Totals', 'wcpl-product-likes' ); ?></a>
				</nav>
				<div id="wcpl-product-likes-dashboard-modal" data-spinner-url="<?php echo esc_url( includes_url( 'images/spinner-2x.gif' ) ); ?>"></div>

				<?php if ( 'product-totals' == $tab ) { ?>

					<table id="wcpl-product-likes-dashboard-datatable" class="widefat fixed striped">

						<thead>
							<tr>
								<th><?php esc_html_e( 'Product', 'wcpl-product-likes' ); ?></th>
								<th><?php esc_html_e( 'SKU', 'wcpl-product-likes' ); ?></th>
								<th><?php esc_html_e( 'Likes', 'wcpl-product-likes' ); ?></th>
							</tr>
						</thead>
						<tbody>

							<?php

							$query = new WC_Product_Query(
								array(
									'limit'		=> -1,
									'orderby'	=> 'name',
									'order'		=> 'ASC',
									'return'	=> 'ids',
								)
							);

							$products = $query->get_products();

							foreach ( $products as $product_id ) {

								$sku = get_post_meta( $product_id, '_sku', true );
								$sku = ( !empty( $sku ) ? $sku : esc_html__( '–', 'wcpl-product-likes' ) );

								$likes = get_post_meta( $product_id, '_wcpl_product_likes_likes', true );
								$likes = ( !empty( $likes ) ? $likes : '0' );

								?>

								<tr>
									<td><a href="<?php echo esc_url( get_permalink( $product_id ) ); ?>" target="_blank"><?php echo esc_html( get_the_title( $product_id ) ); ?></a></td>
									<td><?php echo esc_html( $sku ); ?></td>
									<td><?php echo ( (int) $likes > 0 ? '<a href="#TB_inline?&width=400&height=300&inlineId=wcpl-product-likes-dashboard-modal" class="thickbox" data-type="product-totals" data-product-id="' . esc_attr( $product_id ) . '">' . esc_html( $likes ) . '</a>' : '0' ); ?></td>
								</tr>

							<?php } ?>

						</tbody>

					</table>

					<?php

				} elseif ( 'customer-totals' == $tab ) {

					?>

					<table id="wcpl-product-likes-dashboard-datatable" class="widefat fixed striped">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Customer', 'wcpl-product-likes' ); ?></th>
								<th><?php esc_html_e( 'Email', 'wcpl-product-likes' ); ?></th>
								<th><?php esc_html_e( 'Phone', 'wcpl-product-likes' ); ?></th>
								<th><?php esc_html_e( 'Likes', 'wcpl-product-likes' ); ?></th>
							</tr>
						</thead>
						<tbody>

							<?php

							$customers = get_users(
								array(
									'role__in'	=> array(
										'customer',
										'administrator',
										'shop_manager',
									),
									'number'	=> -1,
									'fields'	=> array(
										'ID',
										'user_email',
										'display_name',
									)
								)
							);

							foreach ( $customers as $customer ) {

								$name = get_user_meta( $customer->ID, 'first_name', true ) . ' ' . get_user_meta( $customer->ID, 'last_name', true );
								$name = ( ' ' !== $name ? $name : $customer->display_name );
								$phone = get_user_meta( $customer->ID, 'billing_phone', true );

								$likes = $wpdb->get_results(
									$wpdb->prepare(
										"SELECT COUNT(*) as total FROM {$wpdb->prefix}wcpl_product_likes WHERE `user_id` = %d;",
										$customer->ID
									)
								);

								?>

								<tr>
									<td><a href="<?php echo esc_url( admin_url( 'user-edit.php?user_id=' . $customer->ID ) ); ?>" target="_blank"><?php echo esc_html( $name ); ?></a></td>
									<td><a href="mailto:<?php echo esc_html( $customer->user_email ); ?>"><?php echo esc_html( $customer->user_email ); ?></a></td>
									<td><a href="tel:<?php echo esc_html( str_replace( ' ', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a></td>
									<td><?php echo ( (int) $likes[0]->total > 0 ? '<a href="#TB_inline?&width=400&height=300&inlineId=wcpl-product-likes-dashboard-modal" class="thickbox" data-type="customer-totals" data-customer-id="' . esc_attr( $customer->ID ) . '">' . esc_html( $likes[0]->total ) . '</a>' : '0' ); ?></td>
								</tr>

							<?php } ?>

						</tbody>
					</table>

				<?php } ?>

			</div>

			<?php

		}

		public function modal_population() {

			$response = '';

			if ( isset( $_POST['nonce'] ) ) {

				if ( wp_verify_nonce( sanitize_key( $_POST['nonce'] ), 'wcpl_product_likes_dashboard_modal_population' ) ) {

					if ( isset( $_POST['type'] ) ) {

						global $wpdb;

						$type = sanitize_text_field( $_POST['type'] );

						if ( 'product-totals' == $type ) {
	
							if ( isset( $_POST['product_id'] ) ) {
	
								$product_id = sanitize_text_field( $_POST['product_id'] );
	
								$customers = $wpdb->get_results(
									$wpdb->prepare(
										"SELECT user_id FROM {$wpdb->prefix}wcpl_product_likes WHERE `product_id` = %d;",
										$product_id
									)
								);
			
								$response .= '<p><strong>' . sprintf( wp_kses_post( 'Customers who liked %s:', 'wcpl-product-likes' ), get_the_title( $product_id ) ) . '</strong></p>';
			
								if ( !empty( $customers ) ) {
									
									$guest_likes = 0;
			
									$response .= '<ul>';
			
									foreach ( $customers as $customer ) {
			
										if ( is_numeric( $customer->user_id ) ) { // Filters out guests
			
											$user = get_userdata( $customer->user_id );
											$name = $user->first_name . ' ' . $user->last_name;
											$name = ( ' ' !== $name ? $name : $user->display_name );
			
											$response .= '<li><a href="' . esc_url( admin_url( 'user-edit.php?user_id=' . $customer->user_id ) ) . '" target="_blank">' . esc_html( $name ) . '</a></li>';
			
										} else {
			
											$guest_likes++;
			
										}
			
									}
			
									$response .= '</ul>';
			
									if ( $guest_likes > 0 ) {
			
										$response .= '<hr>';
										// translators: %s: guest likes total
										$response .= '<p><strong>' . sprintf( esc_html__( 'Guest likes: %d', 'wcpl-product-likes' ), $guest_likes ) . '</strong></p>';
			
									}
			
								}
	
							}
	
						} elseif ( 'customer-totals' == $type ) {
	
							if ( isset( $_POST['customer_id'] ) ) {
	
								$customer_id = sanitize_text_field( $_POST['customer_id'] );
	
								$products = $wpdb->get_results(
									$wpdb->prepare(
										"SELECT product_id FROM {$wpdb->prefix}wcpl_product_likes WHERE `user_id` = %d;",
										$customer_id
									)
								);
		
								$response .= '<p><strong>' . sprintf( wp_kses_post( 'Products liked by %s:', 'wcpl-product-likes' ), get_user_meta( $customer_id, 'nickname', true ) ) . '</strong></p>';
		
								if ( !empty( $products ) ) {
		
									$response .= '<ul>';
									
									foreach ( $products as $product ) {
		
										$response .= '<li><a href="' . get_permalink( $product->product_id ) . '" target="_blank">' . get_the_title( $product->product_id ) . '</a></li>';
		
									}
		
									$response .= '</ul>';
		
								}	
	
							}
	
						}

					}

				}

			}

			echo wp_kses_post( $response );

			exit;

		}

	}

}
