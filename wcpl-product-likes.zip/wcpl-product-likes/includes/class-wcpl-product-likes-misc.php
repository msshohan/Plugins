<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( !class_exists( 'WCPL_Product_Likes_Misc' ) ) {

	class WCPL_Product_Likes_Misc {

		public function __construct() {

			add_filter( 'woocommerce_duplicate_product_exclude_meta', array( $this, 'product_duplicate_exclude_post_meta' ) );

		}

		public function product_duplicate_exclude_post_meta( $excluded_post_meta ) {

			$excluded_post_meta[] = '_wcpl_product_likes_likes'; // Likes post meta is excluded as this should not be duplicated as the duplicated product should not have the same number of likes as the original, if this remains it also means the post meta is not synced correctly with the database data and would cause inconsistencies until post meta debug performed

			return $excluded_post_meta;

		}

	}

}
