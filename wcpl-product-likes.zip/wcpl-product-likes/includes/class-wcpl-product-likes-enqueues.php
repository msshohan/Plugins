<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( !class_exists( 'WCPL_Product_Likes_Enqueues' ) ) {

	class WCPL_Product_Likes_Enqueues {

		public function __construct() {

			add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueues' ) );
			add_action( 'admin_footer', array( $this, 'admin_enqueues_inline' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'public_enqueues' ) );
			add_action( 'wp_footer', array( $this, 'public_enqueues_inline' ) );

		}

		public function admin_enqueues() {

			global $pagenow;

			wp_enqueue_script( 'jquery' );

			wp_enqueue_style(
				'wcpl-product-likes-admin',
				plugins_url( 'assets/css/admin.min.css', __DIR__ ),
				array(),
				WCPL_PRODUCT_LIKES_VERSION,
				'all'
			);

			if ( 'edit.php' == $pagenow ) {

				if ( isset( $_GET['page'] ) ) {

					if ( 'wcpl-product-likes' == $_GET['page'] ) {

						add_thickbox();

						wp_enqueue_script(
							'wcpl-product-likes-admin',
							plugins_url( 'assets/js/admin.min.js', __DIR__ ),
							array(
								'jquery',
								'wp-i18n',
							),
							WCPL_PRODUCT_LIKES_VERSION
						);

						wp_enqueue_script(
							'wcpl-product-likes-datatables',
							plugins_url( 'libraries/DataTables/datatables.min.js', __DIR__ ),
							array( 'jquery' ),
							WCPL_PRODUCT_LIKES_VERSION
						);

						add_action( 'admin_footer', function() {

							?>

							<script>
								jQuery( document ).ready( function( $ ) {

									$( '#wcpl-product-likes-dashboard-datatable' ).DataTable({
										'dom': '<"top"fiplB>rt<"bottom"fiplB>',
										'pageLength': 100,
										'order': [ 0, 'asc' ],
										'drawCallback': function() {
											$( '.dataTables_paginate a' ).addClass( 'button' );
											$( '.dataTables_paginate a.current' ).addClass( 'button-primary' );
										},
										'buttons': [
											{
												'extend': 'print',
												'text': "<?php esc_html_e( 'Print', 'wcpl-product-likes' ); ?>",
												'className': 'button',
												'exportOptions': {
													"columns": ':visible'
												}
											},
											{
												'extend': "csvHtml5",
												'text': "<?php esc_html_e( 'Export', 'wcpl-product-likes' ); ?>",
												'className': 'button',
												'exportOptions': {
													'columns': ':visible'
												}
											}
										],
										'language': {
											'decimal': 			'',
											'emptyTable':		"<?php esc_html_e( 'No data available', 'wcpl-product-likes' ); ?>",
											<?php // translators: %1$s: start, %2$s: end, %3$s: total numbers ?>
											'info':				"<?php echo sprintf( esc_html__( 'Showing %1$s to %2$s of %3$s', 'wcpl-product-likes' ), '_START_', '_END_', '_TOTAL_' ); ?>",
											'infoEmpty':		"<?php esc_html_e( 'Showing 0 to 0 of 0', 'wcpl-product-likes' ); ?>",
											<?php // translators: %s: total ?>
											'infoFiltered':		"<?php echo sprintf( esc_html__( '(filtered from %s)', 'wcpl-product-likes' ), '_MAX_' ); ?>",
											'infoPostFix':		'',
											'thousands':		'',
											<?php // translators: %s: select field to choose amount ?>
											'lengthMenu':		"<?php echo sprintf( esc_html__( 'Show %s', 'wcpl-product-likes' ), '_MENU_' ); ?>",
											'loadingRecords':	"<?php esc_html_e( 'Loading...', 'wcpl-product-likes' ); ?>",
											'processing':		"<?php esc_html_e( 'Processing...', 'wcpl-product-likes' ); ?>",
											'search':			"<?php esc_html_e( 'Search', 'wcpl-product-likes' ); ?>",
											'zeroRecords':		"<?php esc_html_e( 'No matching records found.', 'wcpl-product-likes' ); ?>",
											'paginate': {
												'first':	"<?php esc_html_e( 'First', 'wcpl-product-likes' ); ?>",
												'last':		"<?php esc_html_e( 'Last', 'wcpl-product-likes' ); ?>",
												'next':		"<?php esc_html_e( 'Next', 'wcpl-product-likes' ); ?>",
												'previous': "<?php esc_html_e( 'Previous', 'wcpl-product-likes' ); ?>"
											},
											'aria': {
												'sortAscending':	"<?php esc_html_e( ':', 'wcpl-product-likes' ); ?> <?php esc_html_e( 'activate to sort column ascending', 'wcpl-product-likes' ); ?>",
												'sortDescending':	"<?php esc_html_e( ':', 'wcpl-product-likes' ); ?> <?php esc_html_e( 'activate to sort column descending', 'wcpl-product-likes' ); ?>"
											}
										},
									});

								});
							</script>

							<?php

						} );

					}

				}

			}

		}

		public function admin_enqueues_inline() {
			
			global $pagenow;

			if ( 'edit.php' == $pagenow ) {

				if ( isset( $_GET['page'] ) ) {

					if ( 'wcpl-product-likes' == $_GET['page'] ) {

						?>

						<script>
							var wcplProductLikesAjaxUrl = "<?php echo esc_html( admin_url( 'admin-ajax.php' ) ); ?>";
							var wcplProductLikesDashboardModalPopulationNonce = "<?php echo esc_html( wp_create_nonce( 'wcpl_product_likes_dashboard_modal_population' ) ); ?>";
						</script>

						<?php

					}

				}

			}

		}

		public function public_enqueues() {

			wp_enqueue_script( 'jquery' );

			wp_enqueue_script(
				'wcpl-product-likes-public',
				plugins_url( 'assets/js/public.min.js', __DIR__ ),
				array(
					'jquery',
					'wp-i18n',
				),
				WCPL_PRODUCT_LIKES_VERSION
			);

			if ( get_option( 'wcpl_product_likes_styles' ) == 'yes' ) {

				wp_enqueue_style(
					'wcpl-product-likes-public',
					plugins_url( 'assets/css/public.min.css', __DIR__ ),
					array(),
					WCPL_PRODUCT_LIKES_VERSION,
					'all'
				);

			}

		}

		public function public_enqueues_inline() {

			?>

			<script>
				var wcplProductLikesAjaxUrl = "<?php echo esc_html( admin_url( 'admin-ajax.php' ) ); ?>";
				var wcplProductLikesUpdateNonce = "<?php echo esc_html( wp_create_nonce( 'wcpl_product_likes_update' ) ); ?>";
			</script>

			<?php

		}

	}

}
