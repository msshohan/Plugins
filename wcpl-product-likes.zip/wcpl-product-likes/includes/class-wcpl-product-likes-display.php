<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( !class_exists( 'WCPL_Product_Likes_Display' ) ) {

	class WCPL_Product_Likes_Display {

		public function __construct() {

			add_filter( 'body_class', array( $this, 'body_class' ) );
			add_action( 'init', array( $this, 'cookie' ) );
			add_action( 'woocommerce_product_meta_start', array( $this, 'product_pages' ), 0 ); // 0 so before everything else
			add_action( 'woocommerce_after_add_to_cart_form', array( $this, 'product_pages' ) ); // Nothing else hooked from core WooCommerce so default priority
			add_action( 'woocommerce_after_shop_loop_item', array( $this, 'product_archive_pages' ), 20 ); // 20 so after woocommerce_template_loop_add_to_cart at 10
			add_filter( 'woocommerce_blocks_product_grid_item_html', array( $this, 'product_blocks' ), 10, 3 );
			add_action( 'wp_ajax_wcpl_product_likes_update', array( $this, 'update_likes' ) );
			add_action( 'wp_ajax_nopriv_wcpl_product_likes_update', array( $this, 'update_likes' ) );

		}

		public function body_class( $classes ) {

			$classes[] = 'wcpl-product-likes-icon-' . get_option( 'wcpl_product_likes_icon' ); // This is currently used soley for Storefront account tabs CSS
			return $classes;

		}

		public function cookie() {

			if ( !isset( $_COOKIE['wcpl_product_likes'] ) ) {

				setcookie( 'wcpl_product_likes', wp_generate_uuid4(), time() + ( 86400 * 30 ), '/' );

			}

		}

		public function product_pages() {

			if ( 'woocommerce_product_meta_start' == current_filter() && true == apply_filters( 'wcpl_product_likes_products_alternative_hook', false ) ) {

				return;

			}

			if ( 'woocommerce_after_add_to_cart_form' == current_filter() && false == apply_filters( 'wcpl_product_likes_products_alternative_hook', false ) ) {

				return;

			}

			if ( get_option( 'wcpl_product_likes_products' ) == 'yes' ) {

				global $post;
				$product_id = $post->ID;

				$this->button( $product_id, true );

			}

		}

		public function product_archive_pages() {

			if ( get_option( 'wcpl_product_likes_archives' ) == 'yes' ) {

				global $post;
				$product_id = $post->ID;

				$this->button( $product_id, true );

			}

		}

		public function product_blocks( $block, $data, $product ) {

			if ( get_option( 'wcpl_product_likes_blocks' ) == 'yes' ) {

				$product_id = $product->get_id();
				$block_wrapper_class = 'wp-block-button wc-block-grid__product-add-to-cart';
				$block = preg_replace( '/<div class="' . preg_quote( $block_wrapper_class ) . '">(.+?)<\/div>/s', '<div class="' . $block_wrapper_class . '">$1</div>' . $this->button( $product_id, false ), $block );

			}

			return $block;

		}

		public function button( $product_id, $echo = true ) {

			if ( !empty( $product_id ) ) {

				if ( $this->user_logged_in() == true || ( $this->user_logged_in() == false && get_option( 'wcpl_product_likes_not_logged_in' ) == 'yes' ) ) {

					global $wpdb;
	
					$user_id = $this->user_id();
					$product_likes = get_post_meta( $product_id, '_wcpl_product_likes_likes', true );
					$product_likes = (int) ( !empty( $product_likes ) ? $product_likes : '0' );
					$product_liked = $wpdb->get_results( $wpdb->prepare( "SELECT COUNT(*) AS liked FROM {$wpdb->prefix}wcpl_product_likes WHERE product_id = %d AND user_id = %s", array( $product_id, $user_id ) ) );
					$product_liked = (int) ( isset( $product_liked[0] ) ? $product_liked[0]->liked : '0' );
					$button_class = 'wcpl-product-likes-button wcpl-product-likes-button-icon-' . get_option( 'wcpl_product_likes_icon' );
					$like_text = esc_html( apply_filters( 'wcpl_product_likes_like_text', __( 'Like', 'wcpl-product-likes' ) ) );
					$unlike_text = esc_html( apply_filters( 'wcpl_product_likes_unlike_text', __( 'Unlike', 'wcpl-product-likes' ) ) );
					$display_totals = get_option( 'wcpl_product_likes_total' );
	
					ob_start();
	
					echo '<div class="wcpl-product-likes-product" data-product-id="' . esc_html( $product_id ) . '" data-like-text="' . esc_attr( $like_text ) . '" data-unlike-text="' . esc_attr( $unlike_text ) . '">';
	
					if ( 1 == $product_liked ) {
	
						echo '<span class="' . esc_attr( $button_class ) . '" title="' . esc_attr( $unlike_text ) . '" data-type="unlike"><span class="wcpl-product-likes-button-text"></span></span>';
	
					} else {
	
						echo '<span class="' . esc_attr( $button_class ) . '" title="' . esc_attr( $like_text ) . '" data-type="like"><span class="wcpl-product-likes-button-text">' . esc_html( $like_text ) . '</span></span>';
	
					}
	
					if ( 'yes' == $display_totals ) {
	
						echo '<span class="wcpl-product-likes-liked' . ( 0 == $product_likes ? ' wcpl-product-likes-liked-zero' : '' ) . '">' . esc_html( apply_filters( 'wcpl_product_likes_total_before_text', '' ) ) . ' <span class="wcpl-product-likes-liked-total">' . esc_html( $product_likes ) . '</span> ' . esc_html( apply_filters( 'wcpl_product_likes_total_after_text', __( 'likes', 'wcpl-product-likes' ) ) ) . '</span>';
	
					}
	
					echo '</div>';
	
					$likes_button = ob_get_clean();
	
					if ( true == $echo ) {
	
						echo wp_kses_post( $likes_button );
	
					} else {
	
						return $likes_button;
	
					}
	
				}

			}

		}

		public function update_likes() {

			$response = '';

			if ( isset( $_POST['nonce'] ) ) {

				if ( wp_verify_nonce( sanitize_key( $_POST['nonce'] ), 'wcpl_product_likes_update' ) ) {

					global $wpdb;
					$user_id = $this->user_id();
					$product_id = ( isset( $_POST['product_id'] ) ? sanitize_text_field( $_POST['product_id'] ) : '' );
					$type = ( isset( $_POST['type'] ) ? sanitize_text_field( $_POST['type'] ) : '' );

					if ( !empty( $user_id ) ) {

						$existing_like = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}wcpl_product_likes WHERE product_id = %d AND user_id = %s", array( $product_id, $user_id ) ) );

						if ( 'like' == $type ) {

							// Check for existing like incase someone tries changing the type to like on the link to try to inflate likes

							if ( empty( $existing_like ) ) {

								$like = $wpdb->query(
									$wpdb->prepare(
										"INSERT INTO {$wpdb->prefix}wcpl_product_likes VALUES ('', %d, %s);",
										array(
											$product_id,
											$user_id
										)
									)
								);

								if ( $like > 0 ) {

									$this->update_likes_meta( $product_id, 'increase' );
									$response = 'liked_' . $product_id;

								}

							}

						} elseif ( 'unlike' == $type ) {

							// Check for existing like incase someone tries changing the type to unlike on the link to try to deflate likes

							if ( !empty( $existing_like ) ) {

								$unlike = $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}wcpl_product_likes WHERE product_id = %d AND user_id = %s;", array( $product_id, $user_id ) ) );

								if ( $unlike > 0 ) {

									$this->update_likes_meta( $product_id, 'decrease' );
									$response = 'unliked_' . $product_id;

								}

							}

						}

					}

				}

			}

			echo esc_html( $response );

			exit;

		}

		public function user_id() {

			$user_id = get_current_user_id();

			if ( 0 == $user_id ) { // Not logged in

				if ( isset( $_COOKIE['wcpl_product_likes'] ) ) {

					$user_id = sanitize_text_field( $_COOKIE['wcpl_product_likes'] );

				}

			}

			return $user_id;

		}

		public function user_logged_in() {

			$user_id = $this->user_id();
			$user_logged_in = true;

			if ( !empty( $user_id ) ) {

				if ( substr_count( $user_id, '-' ) > 0 ) {

					$user_logged_in = false;

				}

			}

			return $user_logged_in;

		}

		public function update_likes_meta( $product_id, $type ) {

			if ( !empty( $product_id ) ) {

				if ( 'increase' == $type || 'decrease' == $type ) {

					$likes = get_post_meta( $product_id, '_wcpl_product_likes_likes', true );
					$likes = (int) ( !empty( $likes ) ? $likes : '0' );

					if ( 'increase' == $type ) {

						$likes = ++$likes;

					} elseif ( 'decrease' == $type ) {

						$likes = --$likes;

					}

					update_post_meta( $product_id, '_wcpl_product_likes_likes', $likes );

				}				

			}

		}

	}

}
