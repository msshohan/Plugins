<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( !class_exists( 'WCPL_Product_Likes_Debug' ) ) {

	class WCPL_Product_Likes_Debug {

		public function __construct() {

			add_action( 'admin_head', array( $this, 'post_meta' ) );

		}

		public function post_meta() {

			if ( current_user_can( 'administrator' ) ) {

				if ( isset( $_GET['wcpl_product_likes_debug_post_meta'] ) ) {

					if ( '1' == sanitize_text_field( $_GET['wcpl_product_likes_debug_post_meta'] ) ) {

						global $wpdb;

						$wpdb->get_results(
							$wpdb->prepare(
								"DELETE FROM `{$wpdb->prefix}postmeta` WHERE `meta_key` = '_wcpl_product_likes_likes';"
							)
						);

						$products_with_likes = $wpdb->get_results(
							$wpdb->prepare(
								"SELECT product_id, count( product_id ) AS likes FROM `{$wpdb->prefix}wcpl_product_likes` GROUP BY product_id;"
							)
						);

						if ( !empty( $products_with_likes ) ) {

							foreach ( $products_with_likes as $product_with_likes ) {

								update_post_meta( $product_with_likes->product_id, '_wcpl_product_likes_likes', $product_with_likes->likes );

							}

						}

					}

				}

			}

		}

	}

}
