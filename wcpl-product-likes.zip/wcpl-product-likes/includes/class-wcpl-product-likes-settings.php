<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( !class_exists( 'WCPL_Product_Likes_Settings' ) ) {

	class WCPL_Product_Likes_Settings {

		public function __construct() {

			add_filter( 'woocommerce_get_sections_products', array( $this, 'section' ) );
			add_filter( 'woocommerce_get_settings_products', array( $this, 'fields' ), 10, 2 );

		}

		public function section( $sections ) {

			$sections['wcpl-product-likes'] = __( 'Product likes', 'wcpl-product-likes' );
			return $sections;

		}

		public function fields( $settings, $current_section ) {

			if ( 'wcpl-product-likes' == $current_section ) {

				// Section Start

				$settings[] = array(
					'name'	=> esc_html__( 'Product likes', 'wcpl-product-likes' ),
					'id'	=> 'wcpl-product-likes',
					'type'	=> 'title',
				);

				// General

				$settings[] = array(
					'name'				=> esc_html__( 'General', 'wcpl-product-likes' ),
					'id'				=> 'wcpl_product_likes_enable',
					'type'				=> 'checkbox',
					'css'				=> 'min-width:300px;',
					'desc'				=> esc_html__( 'Enable', 'wcpl-product-likes' ),
					'desc_tip'			=> esc_html__( 'Enables product likes across your store, ensure you also enable at least one of the display options below.', 'wcpl-product-likes' ),
					'checkboxgroup'		=> 'start',
				);

				$settings[] = array(
					'id'			=> 'wcpl_product_likes_not_logged_in',
					'type'			=> 'checkbox',
					'css'			=> 'min-width:300px;',
					'desc'			=> esc_html__( 'Enable if not logged in', 'wcpl-product-likes' ),
					'desc_tip'		=> esc_html__( 'Allows users without an account to like products, user will see their likes on products for 30 days or until cookies cleared. After this period likes by a not logged in user will still count towards the total number of product likes.', 'wcpl-product-likes' ),
					'checkboxgroup'	=> '',
				);

				$settings[] = array(
					'id'			=> 'wcpl_product_likes_account',
					'type'			=> 'checkbox',
					'css'			=> 'min-width:300px;',
					'desc'			=> esc_html__( 'Enable in account', 'wcpl-product-likes' ),
					'desc_tip'		=> esc_html__( 'Adds a page within the user\'s account listing the products previously liked.', 'wcpl-product-likes' ),
					'checkboxgroup' => 'end',
				);

				// Display

				$settings[] = array(
					'name'			=> esc_html__( 'Display', 'wcpl-product-likes' ),
					'id'			=> 'wcpl_product_likes_products',
					'type'			=> 'checkbox',
					'css'			=> 'min-width:300px;',
					'desc'			=> esc_html__( 'Display on product pages', 'wcpl-product-likes' ),
					// translators: %1$s: default hook name, %2$s: alternative hook name, %3$s: alternative hook code
					'desc_tip'		=> sprintf( wp_kses_post( 'Displays a product like button on product pages. This is displayed via the %1$s hook which all themes generally include, if this setting is enabled and it is not displayed then ask your theme developer how to enable this hook, if you are using a page builder it should include a product meta block you can add to your page which will include this hook. Alternatively you can display this using the alternative %2$s hook by adding %3$s to your theme\'s functions file, however this is not recommended as this hook is not used if a product is not purchasable (e.g. out of stock).', 'wcpl-product-likes' ), '<code>woocommerce_product_meta_start</code>', '<code>woocommerce_after_add_to_cart_form</code>', "<code>add_filter( 'wcpl_product_likes_products_alternative_hook', '__return_true' );</code>" ),
					'checkboxgroup'	=> 'start',
				);

				$settings[] = array(
					'id'			=> 'wcpl_product_likes_archives',
					'type'			=> 'checkbox',
					'css'			=> 'min-width:300px;',
					'desc'			=> esc_html__( 'Display on product archive pages', 'wcpl-product-likes' ),
					// translators: %s: filter name
					'desc_tip'		=> sprintf( wp_kses_post( 'Displays a product like button on each product in an archive page (e.g. shop page, product categories, search, etc). This is displayed via the %s hook which all themes generally include, if this setting is enabled and it is not displayed then ask your theme developer how to enable this hook, if you are using a page builder it should include a product archive (or similar name) block you can add to your page which will include this hook.', 'wcpl-product-likes' ), '<code>woocommerce_after_shop_loop_item</code>' ),
					'checkboxgroup'	=> '',
				);

				$settings[] = array(
					'id'			=> 'wcpl_product_likes_blocks',
					'type'			=> 'checkbox',
					'css'			=> 'min-width:300px;',
					'desc'			=> esc_html__( 'Display on product blocks', 'wcpl-product-likes' ),
					'desc_tip'		=> esc_html__( 'Displays a product like button on each product in any core WooCommerce product block (excluding the All Products block due to extensibility constraints).', 'wcpl-product-likes' ),
					'checkboxgroup'	=> '',
				);

				$settings[] = array(
					'id'			=> 'wcpl_product_likes_total',
					'type'			=> 'checkbox',
					'css'			=> 'min-width:300px;',
					'desc'			=> esc_html__( 'Display total likes', 'wcpl-product-likes' ),
					'desc_tip'		=> esc_html__( 'Displays the total number of likes if a product has been liked.', 'wcpl-product-likes' ),
					'checkboxgroup'	=> 'end',
				);

				// Icon

				$settings[] = array(
					'id'		=> 'wcpl_product_likes_icon',
					'type'		=> 'select',
					'css'		=> 'min-width:300px;',
					'class'		=> 'wc-enhanced-select',
					'title'		=> __( 'Icon', 'wcpl-product-likes' ),
					'desc'		=> esc_html__( 'Icon type used for product likes. If you wish to use a custom icon set this to none (or disable styles entirely) and apply your own with custom CSS.', 'wcpl-product-likes' ),
					'options'	=> array(
						'heart'	=> esc_html__( 'Heart', 'wcpl-product-likes' ),
						'star'	=> esc_html__( 'Star', 'wcpl-product-likes' ),
						'thumb'	=> esc_html__( 'Thumb', 'wcpl-product-likes' ),
						'none'	=> esc_html__( 'None', 'wcpl-product-likes' ),
					),
				);

				// Styles

				$settings[] = array(
					'name'		=> esc_html__( 'Styles', 'wcpl-product-likes' ),
					'id'		=> 'wcpl_product_likes_styles',
					'type'		=> 'checkbox',
					'css'		=> 'min-width:300px;',
					'desc'		=> esc_html__( 'Enable styles', 'wcpl-product-likes' ),
					'desc_tip'	=> esc_html__( 'Adds styles to product likes, if disabled this will remove all styles from product likes including the icon chosen, this option should only be disabled if you wish to style product likes yourself with CSS.', 'wcpl-product-likes' ),
				);

				// Section End
				
				$settings[] = array(
					'type'	=> 'sectionend',
					'id'	=> 'wcpl-product-likes'
				);


				$settings[] = array(
					'name'	=> esc_html__( 'Post meta', 'wcpl-product-likes' ),
					'id'	=> 'wcpl-product-likes-post-meta', // ID of div not an input
					'type'	=> 'title',
					// translators: %1$s: post meta key, %2$s: example query string, %3$s: example query string url
					'desc'	=> sprintf( wp_kses_post( 'This extension stores product post meta with the key %1$s for the total number of likes. This post meta should not be created/updated through the database, import, custom development or by using clone page/post/product plugins (with the exception of using the duplicate link on products in the dashboard product list) as it is related to data stored outside post meta in a database table for each individual like and both should remain in sync. If the post meta is added/updated you may see inconsistencies when attemping to like or unlike products. If you have attempted to create/update this post meta and have issues then you can resync the post meta by logging into your dashboard as an administrator and adding the query string %2$s to the admin URL and pressing enter e.g. %3$s', 'wcpl-product-likes' ) , '<code>_wcpl_product_likes_likes</code>', '<code>wcpl_product_likes_debug_post_meta=1</code>', '<code>' . esc_url( get_admin_url() ) . '?wcpl_product_likes_debug_post_meta=1</code>' ),
				);

				$settings[] = array(
					'type'	=> 'sectionend',
					'id'	=> 'wcpl-product-likes-post-meta'
				);

				return $settings;

			} else {

				return $settings;

			}

		}

	}

}
