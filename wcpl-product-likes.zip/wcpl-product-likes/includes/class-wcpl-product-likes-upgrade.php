<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( !class_exists( 'WCPL_Product_Likes_Upgrade' ) ) {

	class WCPL_Product_Likes_Upgrade {

		public function __construct() {

			add_action( 'wp_loaded', array( $this, 'upgrade' ) );

		}

		public static function upgrade() {

			$version = get_option( 'wcpl_product_likes_version' );

			if ( WCPL_PRODUCT_LIKES_VERSION !== $version ) {

				global $wpdb;

				if ( version_compare( $version, '1.0.0', '<' ) ) {

					// 1.0.0 - Create likes table

					$table_name = $wpdb->prefix . 'wcpl_product_likes';
					$charset_collate = $wpdb->get_charset_collate();

					$sql = "CREATE TABLE IF NOT EXISTS $table_name (
						like_id bigint(20) AUTO_INCREMENT,
						product_id bigint(20) NOT NULL,
						user_id text NOT NULL,
						PRIMARY KEY (like_id)
					) $charset_collate;";

					require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
					dbDelta( $sql );

					// 1.0.0 - Populate options

					if ( get_option( 'wcpl_product_likes_enable' ) === false ) {

						update_option( 'wcpl_product_likes_enable', 'yes' );

					}

					if ( get_option( 'wcpl_product_likes_not_logged_in' ) === false ) {

						update_option( 'wcpl_product_likes_not_logged_in', 'yes' );

					}

					if ( get_option( 'wcpl_product_likes_account' ) === false ) {

						update_option( 'wcpl_product_likes_account', 'yes' );

					}

					if ( get_option( 'wcpl_product_likes_products' ) === false ) {

						update_option( 'wcpl_product_likes_products', 'yes' );

					}

					if ( get_option( 'wcpl_product_likes_archives' ) === false ) {

						update_option( 'wcpl_product_likes_archives', 'yes' );

					}

					if ( get_option( 'wcpl_product_likes_total' ) === false ) {

						update_option( 'wcpl_product_likes_total', 'yes' );

					}

					if ( get_option( 'wcpl_product_likes_icon' ) === false ) {

						update_option( 'wcpl_product_likes_icon', 'heart' );

					}

					if ( get_option( 'wcpl_product_likes_styles' ) === false ) {

						update_option( 'wcpl_product_likes_styles', 'yes' );

					}

				}

				if ( version_compare( $version, '1.1.0', '<' ) ) {

					// 1.1.0 - Populate likes post meta on products (we added post meta to each product, so we need to populate this for each product with the total number of likes)

					$products_with_likes = $wpdb->get_results(
						$wpdb->prepare(
							"SELECT product_id, count( product_id ) AS likes FROM `{$wpdb->prefix}wcpl_product_likes` GROUP BY product_id;"
						)
					);

					if ( !empty( $products_with_likes ) ) {

						foreach ( $products_with_likes as $product_with_likes ) {

							update_post_meta( $product_with_likes->product_id, '_wcpl_product_likes_likes', $product_with_likes->likes );

						}

					}

				}

				if ( version_compare( $version, '2.0.0', '<' )  ) {

					// 2.0.0 - Populate new options

					if ( get_option( 'wcpl_product_likes_blocks' ) === false ) {

						update_option( 'wcpl_product_likes_blocks', 'yes' );

					}

				}

				update_option( 'wcpl_product_likes_version', WCPL_PRODUCT_LIKES_VERSION );

			}

		}

	}

}
