<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( !class_exists( 'WCPL_Product_Likes_Account' ) ) {

	class WCPL_Product_Likes_Account {

		public function __construct() {

			add_filter( 'woocommerce_account_menu_items', array( $this, 'item' ), 10, 1 );
			add_action( 'woocommerce_account_likes_endpoint', array( $this, 'content' ) );
			add_action( 'init', array( $this, 'endpoint' ) );
			add_filter( 'query_vars', array( $this, 'vars' ), 0 );


		}

		public function item( $items ) {

			if ( !empty( $items ) ) {

				$items_with_likes = array();

				foreach ( $items as $item_key => $item_value ) {

					$items_with_likes[ $item_key ] = $item_value;

					if ( 'downloads' == $item_key ) {

						$items_with_likes['likes'] = esc_html( apply_filters( 'wcpl_product_likes_likes_text', __( 'Likes', 'wcpl-product-likes' ) ) ); // Add likes tab after downloads tab

					}

				}

				return $items_with_likes;

			}

			return $items;

		}

		public function content() {

			global $wpdb;
			$user_id = get_current_user_id(); // Not using get user id function from buttons class as already logged in and don't want the not logged in user ids from that function
			$products_liked = $wpdb->get_results( $wpdb->prepare( "SELECT product_id FROM {$wpdb->prefix}wcpl_product_likes WHERE user_id = %s", $user_id ) );
			$products_liked_ids = array();

			if ( !empty( $products_liked ) ) {

				foreach ( $products_liked as $product_liked ) {

					$product = wc_get_product( $product_liked->product_id );

					if ( !empty( $product ) ) {

						if ( true == $product->is_visible() ) {

							$products_liked_ids[] = $product_liked->product_id;

						}

					}				

				}
				
				echo do_shortcode( '[products paginate="true" limit="20" columns="4" ids="' . implode( ',', $products_liked_ids ) . '"]' );

			} else {

				echo esc_html( apply_filters( 'wcpl_product_likes_likes_none_text', __( 'No products liked yet.', 'wcpl-product-likes' ) ) );

			}

		}

		public function endpoint() {

			add_rewrite_endpoint( 'likes', EP_PAGES );

			// Only flush rewrites once

			if ( get_option( 'wcpl_product_likes_flush_rewrites' ) == 'yes' ) {
				
				flush_rewrite_rules();
				delete_option( 'wcpl_product_likes_flush_rewrites' );
			
			}

		}

		public function vars( $vars ) {

			$vars[] = 'likes';
			return $vars;

		}

	}

}
