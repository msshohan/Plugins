<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( !class_exists( 'WCPL_Product_Likes_Activation' ) ) {

	class WCPL_Product_Likes_Activation {

		public function __construct() {

			register_activation_hook( plugin_dir_path( __DIR__ ) . 'wcpl-product-likes.php', array( $this, 'install' ) );

		}

		public function install() {

			WCPL_Product_Likes_Upgrade::upgrade();

			update_option( 'wcpl_product_likes_flush_rewrites', 'yes' );

		}

	}

}
