jQuery( document ).ready( function( $ ) {

	// Translation

	const { __, _x, _n, _nx } = wp.i18n;

	// Likes update

	$( 'body' ).on( 'click', '.wcpl-product-likes-button', function( e ) {

		e.preventDefault();

		var button = $( this );
		button.addClass( 'wcpl-product-likes-button-loading' );

		var data = {
			'action':		'wcpl_product_likes_update',
			'product_id':	$( this ).parent().attr( 'data-product-id' ),
			'type':			$( this ).attr( 'data-type' ),
			'nonce':		wcplProductLikesUpdateNonce,
		};

		jQuery.post( wcplProductLikesAjaxUrl, data, function( response ) {

			response = $.trim( response ); // Some sites may return a blank line first in the response due to potential theme/extensions so this removes it, otherwise the split below would not work
			response = response.split( '_' );

			var likedTotal = parseInt( $( '.wcpl-product-likes-product[data-product-id="' + response[1] + '"] .wcpl-product-likes-liked-total' ).text() );
			var likeText = $( '.wcpl-product-likes-product[data-product-id="' + response[1] + '"]' ).attr( 'data-like-text' );
			var unlikeText = $( '.wcpl-product-likes-product[data-product-id="' + response[1] + '"]' ).attr( 'data-unlike-text' );

			if ( response[0] == 'liked' ) {

				var likedTotalNew = likedTotal + 1;

				$( '.wcpl-product-likes-product[data-product-id="' + response[1] + '"] .wcpl-product-likes-button' ).attr( 'data-type', 'unlike' );
				$( '.wcpl-product-likes-product[data-product-id="' + response[1] + '"] .wcpl-product-likes-button' ).attr( 'title', unlikeText );
				$( '.wcpl-product-likes-product[data-product-id="' + response[1] + '"] .wcpl-product-likes-button .wcpl-product-likes-button-text' ).hide();
				$( '.wcpl-product-likes-product[data-product-id="' + response[1] + '"] .wcpl-product-likes-liked-total' ).text( likedTotalNew );

				if ( likedTotalNew > 0 ) {

					$( '.wcpl-product-likes-product[data-product-id="' + response[1] + '"] .wcpl-product-likes-liked' ).removeClass( 'wcpl-product-likes-liked-zero' );

				}

			} else {

				var likedTotalNew = likedTotal - 1;

				$( '.wcpl-product-likes-product[data-product-id="' + response[1] + '"] .wcpl-product-likes-button' ).attr( 'data-type', 'like' );
				$( '.wcpl-product-likes-product[data-product-id="' + response[1] + '"] .wcpl-product-likes-button' ).attr( 'title', likeText );
				$( '.wcpl-product-likes-product[data-product-id="' + response[1] + '"] .wcpl-product-likes-button .wcpl-product-likes-button-text' ).text( likeText ).show();
				$( '.wcpl-product-likes-product[data-product-id="' + response[1] + '"] .wcpl-product-likes-liked-total' ).text( likedTotalNew );

				if ( likedTotalNew == 0 ) {

					$( '.wcpl-product-likes-product[data-product-id="' + response[1] + '"] .wcpl-product-likes-liked' ).addClass( 'wcpl-product-likes-liked-zero' );

				}

			}

			button.removeClass( 'wcpl-product-likes-button-loading' );

		});

	});

});