jQuery( document ).ready( function( $ ) {

	// Translation

	const { __, _x, _n, _nx } = wp.i18n;

	// Modal population

	$( 'body' ).on( 'click', '#wcpl-product-likes-dashboard-datatable tbody tr td:last-of-type a', function( e ) {

		var modal = $( '#wcpl-product-likes-dashboard-modal' );
		var type = $( this ).attr( 'data-type' );

		modal.html( '<p><img src="' + modal.attr( 'data-spinner-url' ) + '" class="wcpl-product-likes-button-loading"></p>' ); // Must be in <p> due to how Thickbox works

		if ( type == 'product-totals' ) {

			var data = {
				'action':		'wcpl_product_likes_dashboard_modal_population',
				'type':			type,
				'product_id':	$( this ).attr( 'data-product-id' ),
				'nonce':		wcplProductLikesDashboardModalPopulationNonce,
			};

		} else if ( type == 'customer-totals' ) {

			var data = {
				'action':		'wcpl_product_likes_dashboard_modal_population',
				'type':			type,
				'customer_id':	$( this ).attr( 'data-customer-id' ),
				'nonce':		wcplProductLikesDashboardModalPopulationNonce,
			};

		} else {

			return;

		}

		jQuery.post( wcplProductLikesAjaxUrl, data, function( response ) {

			$( '#TB_ajaxContent' ).html( response ); // Specifically #TB_ajaxContent not #wcpl-product-likes-dashboard-modal

		});

	});

});